
When setting environment variables KETTLE_HOME, KETTLE_REPOSITORY, KETTLE_USER AND KETTLE_PASSWORD, 
be careful not to use values with spaces in the name.
In that case you will need to make some manual changes to the shell scripts.

This problem will be resolved in future releases as part of bug #3165

All the best

The development team

