
If you want support for the built-in browser in Linux, please install Mozilla XULRunner.
A lot of distributions ship with this software these days, so we used this as the default configuration option.
If you want you can change the location in spoon.sh with the MOZILLA_FIVE_HOME environment variable.

